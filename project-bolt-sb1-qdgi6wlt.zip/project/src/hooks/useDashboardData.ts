import { useState, useEffect, useCallback } from 'react';
import { SheetService } from '../services/sheetService';
import { SheetData, SummaryStats } from '../types/dashboard';
import { findHeader, getFormattedTimestamp } from '../utils/formatting';

export const useDashboardData = () => {
  const [data, setData] = useState<SheetData[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [summaryStats, setSummaryStats] = useState<SummaryStats>({
    totalAmount: 0,
    totalPaid: 0,
    totalBalance: 0,
    maxPaid: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const calculateSummaryStats = useCallback((data: SheetData[], headers: string[]): SummaryStats => {
    const amountKey = findHeader(headers, ['amount', 'total amount']);
    const paidKey = findHeader(headers, ['paid']);

    if (!amountKey || !paidKey) {
      return { totalAmount: 0, totalPaid: 0, totalBalance: 0, maxPaid: 0 };
    }

    const amounts = data.map(row => parseFloat(row[amountKey]) || 0);
    const paids = data.map(row => parseFloat(row[paidKey]) || 0);

    const totalAmount = amounts.reduce((sum, val) => sum + val, 0);
    const totalPaid = paids.reduce((sum, val) => sum + val, 0);
    const totalBalance = totalAmount - totalPaid;
    const maxPaid = Math.max(...paids, 0);

    return { totalAmount, totalPaid, totalBalance, maxPaid };
  }, []);

  const fetchData = useCallback(async () => {
    try {
      setError(null);
      const result = await SheetService.fetchSheetData();
      
      setData(result.data);
      setHeaders(result.headers);
      setSummaryStats(calculateSummaryStats(result.data, result.headers));
      setLastUpdated(getFormattedTimestamp());
      setLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setLoading(false);
    }
  }, [calculateSummaryStats]);

  useEffect(() => {
    fetchData();
    
    const interval = setInterval(fetchData, 10000); // Auto-refresh every 10 seconds
    
    return () => clearInterval(interval);
  }, [fetchData]);

  return {
    data,
    headers,
    summaryStats,
    loading,
    error,
    lastUpdated,
    refetch: fetchData
  };
};