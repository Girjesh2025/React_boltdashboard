import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { SheetData } from '../../types/dashboard';
import { findHeader } from '../../utils/formatting';

ChartJS.register(ArcElement, Tooltip, Legend);

interface CategoryChartProps {
  data: SheetData[];
  headers: string[];
}

export const CategoryChart: React.FC<CategoryChartProps> = ({ data, headers }) => {
  const amountKey = findHeader(headers, ['amount', 'total amount']);
  const paidKey = findHeader(headers, ['paid']);

  if (!amountKey || !paidKey) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">
        Missing required columns: Amount and Paid
      </div>
    );
  }

  const totalAmount = data.reduce((sum, row) => sum + (parseFloat(row[amountKey]) || 0), 0);
  const totalPaid = data.reduce((sum, row) => sum + (parseFloat(row[paidKey]) || 0), 0);
  const totalBalance = totalAmount - totalPaid;

  const chartData = {
    labels: ['Total Paid', 'Total Balance'],
    datasets: [
      {
        data: [totalPaid, totalBalance],
        backgroundColor: ['rgba(34, 197, 94, 0.8)', 'rgba(239, 68, 68, 0.8)'],
        borderColor: ['rgba(34, 197, 94, 1)', 'rgba(239, 68, 68, 1)'],
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '60%',
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
        },
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: 'white',
        bodyColor: 'white',
      },
    },
  };

  return <Doughnut data={chartData} options={options} />;
};