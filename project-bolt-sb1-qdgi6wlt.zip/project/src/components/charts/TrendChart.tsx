import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { SheetData } from '../../types/dashboard';
import { findHeader } from '../../utils/formatting';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface TrendChartProps {
  data: SheetData[];
  headers: string[];
}

export const TrendChart: React.FC<TrendChartProps> = ({ data, headers }) => {
  const dateKey = findHeader(headers, ['date']);
  const amountKey = findHeader(headers, ['amount', 'total amount']);

  if (!dateKey || !amountKey) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">
        Missing required columns: Date and Amount
      </div>
    );
  }

  const sortedData = data
    .map(row => ({
      date: new Date(row[dateKey]),
      amount: parseFloat(row[amountKey]) || 0
    }))
    .filter(row => !isNaN(row.date.getTime()))
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  const chartData = {
    labels: sortedData.map(d => d.date.toLocaleDateString()),
    datasets: [
      {
        label: 'Amount',
        data: sortedData.map(d => d.amount),
        fill: true,
        backgroundColor: 'rgba(168, 85, 247, 0.1)',
        borderColor: 'rgba(168, 85, 247, 1)',
        pointBackgroundColor: 'rgba(168, 85, 247, 1)',
        pointBorderColor: 'white',
        pointBorderWidth: 2,
        tension: 0.3,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: 'white',
        bodyColor: 'white',
      },
    },
    scales: {
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
      y: {
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
    },
  };

  return <Line data={chartData} options={options} />;
};