import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { SheetData } from '../../types/dashboard';
import { findHeader } from '../../utils/formatting';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface SalesChartProps {
  data: SheetData[];
  headers: string[];
}

export const SalesChart: React.FC<SalesChartProps> = ({ data, headers }) => {
  const retailerKey = findHeader(headers, ['retailer', 'name', 'customer', 'client', 'shop']);
  const amountKey = findHeader(headers, ['amount', 'total amount', 'value', 'price', 'sum']);

  console.log('SalesChart - Available headers:', headers);
  console.log('SalesChart - Found retailer key:', retailerKey);
  console.log('SalesChart - Found amount key:', amountKey);
  console.log('SalesChart - Data sample:', data.slice(0, 2));

  if (!retailerKey || !amountKey) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500 text-center p-4">
        <div>
          <p className="font-semibold mb-2">Missing required columns</p>
          <p className="text-sm">Available headers: {headers.join(', ')}</p>
          <p className="text-sm mt-2">Looking for: Retailer/Name and Amount columns</p>
        </div>
      </div>
    );
  }

  const salesByRetailer = data.reduce((acc, row) => {
    const retailer = row[retailerKey] || 'Unknown';
    const amount = parseFloat(row[amountKey]?.toString().replace(/[^\d.-]/g, '')) || 0;
    acc[retailer] = (acc[retailer] || 0) + amount;
    return acc;
  }, {} as Record<string, number>);

  console.log('SalesChart - Sales by retailer:', salesByRetailer);

  if (Object.keys(salesByRetailer).length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500 text-center">
        <p>No data available for chart</p>
      </div>
    );
  }

  const chartData = {
    labels: Object.keys(salesByRetailer),
    datasets: [
      {
        label: 'Total Amount',
        data: Object.values(salesByRetailer),
        backgroundColor: 'rgba(67, 97, 238, 0.8)',
        borderColor: 'rgba(67, 97, 238, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: Object.keys(salesByRetailer).length > 5 ? 'y' as const : 'x' as const,
    plugins: {
      legend: {
        display: true,
        position: 'top' as const,
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: 'white',
        bodyColor: 'white',
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ₹${context.parsed.y || context.parsed.x}`;
          }
        }
      },
    },
    scales: {
      x: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
        ticks: {
          callback: function(value: any) {
            return typeof value === 'number' ? `₹${value}` : value;
          }
        }
      },
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
        ticks: {
          callback: function(value: any) {
            return typeof value === 'number' ? `₹${value}` : value;
          }
        }
      },
    },
  };

  return <Bar data={chartData} options={options} />;
};