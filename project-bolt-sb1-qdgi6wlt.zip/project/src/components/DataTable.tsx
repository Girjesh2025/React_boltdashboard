import React from 'react';
import { SheetData } from '../types/dashboard';

interface DataTableProps {
  headers: string[];
  data: SheetData[];
}

export const DataTable: React.FC<DataTableProps> = ({ headers, data }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-4 rounded-t-xl flex justify-between items-center">
        <span className="font-semibold text-lg">📋 Data Records</span>
        <small className="bg-white/20 px-3 py-1 rounded-full text-sm">
          Records: {data.length}
        </small>
      </div>
      
      <div className="p-4">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-200">
                {headers.map((header, index) => (
                  <th key={index} className="text-left py-3 px-2 font-semibold text-gray-700">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  {headers.map((header, headerIndex) => (
                    <td key={headerIndex} className="py-3 px-2 text-gray-600">
                      {row[header] || ''}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};