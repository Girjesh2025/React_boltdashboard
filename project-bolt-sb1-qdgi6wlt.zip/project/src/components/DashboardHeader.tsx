import React from 'react';
import { RefreshCw } from 'lucide-react';

interface DashboardHeaderProps {
  lastUpdated: string;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({ lastUpdated }) => {
  return (
    <div className="text-center mb-8 px-4">
      <h1 className="text-4xl md:text-5xl font-bold text-white mb-3 text-shadow-lg">
        📊 Live Payment Dashboard
      </h1>
      <p className="text-white/90 text-lg mb-4">
        Real-time data visualization from your Google Spreadsheet
      </p>
      
      <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-full border border-white/30">
        <RefreshCw className="w-4 h-4 animate-spin" />
        <span className="text-sm font-medium">Auto-refreshing...</span>
      </div>
      
      {lastUpdated && (
        <p className="text-white/80 text-sm mt-3">
          Last updated: {lastUpdated}
        </p>
      )}
    </div>
  );
};