import React from 'react';
import { SummaryStats } from '../types/dashboard';
import { formatCurrency } from '../utils/formatting';

interface SummaryCardsProps {
  stats: SummaryStats;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({ stats }) => {
  const summaryData = [
    {
      label: 'Total Amount',
      value: formatCurrency(stats.totalAmount),
      bgClass: 'bg-gradient-to-br from-blue-800 to-blue-600'
    },
    {
      label: 'Total Paid',
      value: formatCurrency(stats.totalPaid),
      bgClass: 'bg-gradient-to-br from-green-700 to-green-500'
    },
    {
      label: 'Total Balance',
      value: formatCurrency(stats.totalBalance),
      bgClass: 'bg-gradient-to-br from-yellow-600 to-yellow-500'
    },
    {
      label: 'Maximum Paid',
      value: formatCurrency(stats.maxPaid),
      bgClass: 'bg-gradient-to-br from-pink-700 to-pink-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {summaryData.map((item, index) => (
        <div
          key={index}
          className={`${item.bgClass} p-6 rounded-xl text-white text-center transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl`}
        >
          <div className="text-sm font-medium opacity-90 mb-2">
            {item.label}
          </div>
          <div className="text-2xl font-bold">
            {item.value}
          </div>
        </div>
      ))}
    </div>
  );
};