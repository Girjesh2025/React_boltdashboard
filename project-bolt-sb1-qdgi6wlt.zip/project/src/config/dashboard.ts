import { DashboardConfig } from '../types/dashboard';

export const CONFIG: DashboardConfig = {
  apiKey: 'AIzaSyAq1MGDquoQcawJl5CH1HhNC3ayBcoBtYE',
  sheetId: '1fT9OdZkYf9IIm7m-geXHeQzqlq-8zpwuKF6l0rlI9Io',
  sheetName: 'Sheet1'
};