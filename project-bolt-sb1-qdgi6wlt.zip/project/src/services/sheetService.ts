import { CONFIG } from '../config/dashboard';
import { SheetData } from '../types/dashboard';

export class SheetService {
  static async fetchSheetData(): Promise<{ headers: string[]; data: SheetData[] }> {
    try {
      const url = `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.sheetId}/values/${CONFIG.sheetName}?key=${CONFIG.apiKey}`;
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}. Check API key and Sheet permissions.`);
      }

      const result = await response.json();
      
      if (result.values && result.values.length > 1) {
        const headers = result.values[0];
        const rows = result.values.slice(1).filter((row: string[]) => 
          row.some(cell => cell && cell.trim() !== '')
        );

        const data = rows.map((row: string[]) => {
          const obj: SheetData = {};
          headers.forEach((header: string, index: number) => {
            obj[header] = row[index] || '';
          });
          return obj;
        });

        return { headers, data };
      } else {
        throw new Error('No data found in the spreadsheet.');
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }
}