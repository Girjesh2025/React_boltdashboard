export interface SheetData {
  [key: string]: string;
}

export interface SummaryStats {
  totalAmount: number;
  totalPaid: number;
  totalBalance: number;
  maxPaid: number;
}

export interface ChartDataPoint {
  date: Date;
  amount: number;
}

export interface DashboardConfig {
  apiKey: string;
  sheetId: string;
  sheetName: string;
}