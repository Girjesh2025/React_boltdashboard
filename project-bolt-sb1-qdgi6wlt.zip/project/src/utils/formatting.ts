/**
 * Formats a number as Indian Rupees (₹).
 */
export function formatCurrency(num: number): string {
  if (typeof num !== 'number') return '₹0';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
}

/**
 * Finds a header in a case-insensitive way.
 */
export function findHeader(headers: string[], possibleNames: string[]): string | null {
  for (const name of possibleNames) {
    const foundHeader = headers.find(h => h.toLowerCase().trim() === name.toLowerCase());
    if (foundHeader) return foundHeader;
  }
  return null;
}

/**
 * Updates the timestamp display.
 */
export function getFormattedTimestamp(): string {
  const now = new Date();
  return now.toLocaleString();
}