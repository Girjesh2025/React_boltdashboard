import React from 'react';
import { DashboardHeader } from './components/DashboardHeader';
import { SummaryCards } from './components/SummaryCards';
import { DataTable } from './components/DataTable';
import { ChartCard } from './components/ChartCard';
import { SalesChart } from './components/charts/SalesChart';
import { CategoryChart } from './components/charts/CategoryChart';
import { TrendChart } from './components/charts/TrendChart';
import { useDashboardData } from './hooks/useDashboardData';
import { AlertCircle, Loader2 } from 'lucide-react';

function App() {
  const { data, headers, summaryStats, loading, error, lastUpdated } = useDashboardData();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-800 flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4" />
          <p className="text-xl font-semibold">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-800 py-6">
      <div className="max-w-7xl mx-auto px-4">
        <DashboardHeader lastUpdated={lastUpdated} />
        
        {error ? (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        ) : (
          <>
            <SummaryCards stats={summaryStats} />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <div className="lg:col-span-2">
                <DataTable headers={headers} data={data} />
              </div>
              <div>
                <ChartCard title="📊 Amount by Retailer">
                  <SalesChart data={data} headers={headers} />
                </ChartCard>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ChartCard title="🥧 Paid vs. Balance">
                <CategoryChart data={data} headers={headers} />
              </ChartCard>
              <ChartCard title="📈 Trend Analysis (by Date)">
                <TrendChart data={data} headers={headers} />
              </ChartCard>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default App;